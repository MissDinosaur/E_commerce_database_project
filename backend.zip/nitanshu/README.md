.
├── backend
│   ├── app
│   │   └── main.py
│   ├── Dockerfile
│   └── requirements.txt
├── databases
│   ├── mongo
│   │   ├── Dockerfile
│   │   └── init.js
│   ├── neo4j
│   │   ├── Dockerfile
│   │   └── init.cypher
│   └── postgres
│       ├── Dockerfile
│       └── init.sql
├── data_pipeline
│   ├── Dockerfile
│   ├── ingestion
│   │   ├── mongo_ingest.py
│   │   ├── neo4j_ingest.py
│   │   └── postgres_ingest.py
│   ├── ml
│   │   ├── fraud_detection.py
│   │   ├── fraud_model.pkl
│   │   ├── predict.py
│   │   └── train_model.py
│   ├── processing
│   │   └── transform.py
│   ├── requirements.txt
│   └── visualization
│       └── generate_graphs.py
├── docker-compose.yml
├── frontend
│   ├── checkout.html
│   ├── home.html
│   ├── login.html
│   ├── registration.html
│   └── styles.css
├── logs
│   ├── store_logs_neo4j.py
│   └── store_logs_postgres.py
├── README.md
├── scripts
│   ├── setup.py
│   └── test_api.py
├── tests
│   ├── test_api.py
│   └── test_ml.py
└── tmp
    ├── db.txt
    └── folder_struct.txt

17 directories, 35 files
